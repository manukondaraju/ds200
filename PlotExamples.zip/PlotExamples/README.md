This includes the bar, box and scatter plots for datasets downloaded from the https://data.gov.in website.

Bar Plot  : Explains the percentage of population(in particular Scheduled Tribes) below poverty line of the state New Delhi. From the      figure we can observe that there is a decrease and increase in percentage over the years .

Dataset : https://data.gov.in/catalog/below-poverty-line-india


Box Plot : Explains the distribution of the ST's below the poverty line over the years.

Dataset :https://data.gov.in/catalog/below-poverty-line-india


Scatter Plot : Shows the scatter trend of the Foriegn Development Index(FDI) equity inflows over the years of the all types of industries present (ex:- small , medium and large scale). 

Dataset :https://data.gov.in/catalog/foreign-direct-investment-fdi-equity-inflows
