
import pandas as pd
import matplotlib.pyplot as plt
import sys


df=pd.read_csv('fdi_data.csv', header=None, names=['col1', 'col2','col3','col4','col5','col6','col7','col8','col9','col10','col11','col12','col13','col14','col15','col16'])

a=[]
c=[]

for i in range(1,16):
	b=df['col'+str(i)].tolist()		
	c.append(float(b[len(b)-1]))
	a.append(i)	
	
plt.scatter(a,c,label="Equity Flow")
plt.xlabel("Grand total of equity flow of all industries")
plt.ylabel("financial-years(2000-01)-(2016-17)")
plt.title('financial-year-wise-fdi-equity-inflows-2000-01-2016-17')

plt.legend()
plt.show()
