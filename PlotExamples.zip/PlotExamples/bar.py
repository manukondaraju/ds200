import pandas as pd
import matplotlib.pyplot as plt
import sys

df=pd.read_csv('datafile.csv', header=None, names=['1993-94','1999-2000','2004-05'])

getColList=['1993-94','1999-2000','2004-05']
x_axis=[]

filtList1=df['1993-94'].tolist()
filtList2=df['1999-2000'].tolist()
filtList3=df['2004-05'].tolist()
newList=[]

for i in range(1,len(getColList)+1):
	x_axis.append(i)
	if i==1:
		newList.append(float(filtList1[1])/float(filtList1[2]))
	if i==2:	
		newList.append(float(filtList2[1])/float(filtList2[2]))
	if i==3:
		newList.append(float(filtList3[1])/float(filtList3[2]))
		
setWidth=0.5

p1 = plt.bar(x_axis, newList, setWidth, color='green')
plt.xticks(x_axis,getColList,rotation = 0,size=14,ha='left')
plt.xlabel("Years")
plt.ylabel("Percentage of ST's below poverty line")
plt.title('Population below poverty line - Scheduled Tribes')
plt.legend()
plt.show()
